<?php defined('SYSPATH') or die('No direct script access.');

// Autoloading for PHPExcel
require Kohana::find_file('vendor/PHPExcel/Classes', 'PHPExcel');
