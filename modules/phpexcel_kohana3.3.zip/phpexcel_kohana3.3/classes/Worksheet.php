<?php

defined('SYSPATH') or die('No direct access allowed.');

/**
 * PHP Excel library. Helper class to make spreadsheet creation easier.
 *
 * @package    Spreadsheet
 * @author     Korney Czukowski
 * @license    http://www.gnu.org/licenses/old-licenses/lgpl-2.1.txt    LGPL
 */
class Worksheet extends Kohana_Worksheet {
    
}