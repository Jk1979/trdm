<?php defined('SYSPATH') OR die('No direct access allowed.');

class Model_Test_ORM_MPTT extends ORM_MPTT {
	protected $_table_name = 'test_orm_mptt';
}