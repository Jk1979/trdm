<?php defined('SYSPATH') OR die('No direct access allowed.');

class ORM_MPTT extends Kohana_ORM_MPTT {}